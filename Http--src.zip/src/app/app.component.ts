import { Component, OnInit } from '@angular/core';
import { UserService } from './user.service'; // Import the service

@Component({
  selector: 'app-root',
  template: `
    <h1>User List</h1>
    <ul>
      <li *ngFor="let user of users">
        {{ user.name }} ({{ user.email }})
      </li>
    </ul>
  `
})
export class AppComponent implements OnInit {
  users: any[] = []; // Declare an array to store user data 
  constructor(private userService: UserService) { }

  ngOnInit() {
    // Fetch users when the component is initialized
    this.userService.getUsers().subscribe(
      (data) => {
        this.users = data; // Assign data to the users array
      },
      (error) => {
        console.error('Error fetching users:', error);
      }
    );
  }
}