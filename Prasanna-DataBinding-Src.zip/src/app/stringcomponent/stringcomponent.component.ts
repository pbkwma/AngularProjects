import { Component } from '@angular/core';

@Component({
  selector: 'app-stringcomponent',
  templateUrl: './stringcomponent.component.html',
  styleUrls: ['./stringcomponent.component.css']
})
export class StringcomponentComponent {
name :string = "Prasanna Bala Karthi";
tutor :string = "Rahul"
}
