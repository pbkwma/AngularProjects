import { Component } from '@angular/core';
import { DataService } from './DataService';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'rohit';


  message: string = '';
  newMessage: string = '';
constructor (private dataService: DataService){}

  ngOnInit() {
    // Fetch the initial message from the service
    this.message = this.dataService.getMessage();
  }

  updateMessage() {
    // Update the message in the service and display it
    this.dataService.setMessage(this.newMessage);
    this.message = this.dataService.getMessage();
  }
}